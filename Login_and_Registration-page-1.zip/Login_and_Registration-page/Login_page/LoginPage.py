from tkinter import*
import tkinter
from tkinter import messagebox 
import webbrowser
import sys, os
import sqlite3
import smtplib



#================= S U P P O R T P A G E ===========================
#================= S U P P O R T P A G E ===========================

#========= C L O U D    D A T A    P A G E =========================

def Cloud_page():
	import time;
	import datetime
	from ttkbootstrap import Style
	from tkinter import ttk
	#----------------------------------------
	Cloud = Style(theme='lumen') 
	Cloud = Cloud.master
	Cloud=tkinter.Toplevel()
	Cloud.title("Cloud Data")
	Cloud.config(bg="cadet blue")
	#root.iconbitmap(r'laspotech_logo.ico')

	# MAKE WINDOWS APPEAR ON CENTER OF SCREEN

	app_width = 616
	app_height = 640

	screen_width = root.winfo_screenwidth()
	screen_height = root.winfo_screenheight()

	x = (screen_width / 2) - (app_width / 2)
	y = (screen_height / 2) - (app_height / 2)

	Cloud.geometry(f'{app_width}x{app_height}+{int(x)}+{int(y)}')
	
#----------------------------------------------------------------
	Cloud.resizable(False,False)
	Cloud.focus_force()
	Cloud.grab_set()

	messagebox.showinfo("Connect to a network", "An internet connection is needed for this operation!", parent=Cloud)

	#---------------------------------------------------------
	def send_data():
		try:
			username =  'utomydee@gmail.com'
			password = 'Utomy_dee5'
			Firstname_ =Fname.get()
			MiddleName_ = Mname.get()
			LastName_ = Lname.get() 
			MatricNumber_ =  Matno.get()
			Gender_  = Gender.get() 
			Password_ = Password.get()
			Department_ = Depart.get()
			subject = Matno.get()
			body = "NEW USER (Cloud Data)" + "\n\n" + "Firstname : " + Fname.get() + "\n" + "Middle Name : " + Mname.get() + "\n" + "Last Name : " + Lname.get() + "\n" + "Matric Number : " +  Matno.get() + "\n" + "Gender : " + Gender.get() + "\n" + "Password : " + Password.get()+ "\n" + "Department : " + Depart.get()
			if subject=="" or Firstname_=="" or MiddleName_=="" or LastName_=="" or MatricNumber_=="" or Gender_=="Select Gender"  or Password_==""  or Department_=="Select Department": 
				messagebox.showwarning("Invalid", "All fields are required!\n\nNo field should be left empty!", parent=Cloud)
				#notif.config(text=" All fiels are required! No field should be left empty! ", fg="#FFFF00")
				return

			elif len(Password.get())<=6:
				messagebox.showinfo("Invalid", "Password Incorrect\n\nPassword should be at least 7 characters", parent=Cloud)
				return
			elif len(Matno.get())!=10:
				messagebox.showinfo("Invalid Matric Number", "Enter a valid Matric Number", parent=Cloud)
				return

			else:
				finalMessage = 'Subject: {}\n\n{}'.format(subject, body)
				sever = smtplib.SMTP('smtp.gmail.com', 587)
				sever.starttls()
				sever.login(username, password)
				sever.sendmail(username, to, finalMessage)
				notif.config(text="Request Has been sent successfully!", fg="#CCCC33")
		except:
			notif.config(text="Error sending request! Poor internet connection!", fg='#FFFF00')



	#COMMANDS AND FUNCTIONS
	def clear(): 	#clear entries
		firstname.delete(0,END)
		middlename.delete(0,END)
		lastname.delete(0,END)
		matric_no .delete(0,END)
		Gender.set('Select Gender')
		passw.delete(0,END)
		Depart.set('Select Department')
		notif.config(text="Only Cloud Data if you did not, when Registering!", fg='white')



	#CALLBACK FUNCTION --------NAME
	def checkname(name):
		if name.isalpha():
			return True

		if name=="":
			return True

		else:
			messagebox.showwarning("Invalid","Not allowed "+name[-1], parent=Cloud)
			return False

	#CHECK MATRIC NO REQUIREMENT
	def Check_MatricNo(mat):
		if mat.isdigit():
			return True
		if len(str(mat))==0:
			return True
		else:
			messagebox.showwarning("Invalid","Invalid Entry", parent=Cloud)
			return False
	#----------------------------------------------

	#==================================================================
	#CREATING DATA SELECTION VARIABLE ON GUI
	Fname = StringVar()
	Mname = StringVar()
	Lname = StringVar()
	Matno = StringVar()
	Gender = StringVar()
	Password = StringVar()
	Depart = StringVar()

	DD=StringVar() # Date
	DD.set(time.strftime("%d-%m-%Y"))

	#RESPONSE------------------------------------------
	notif = Label(Cloud, text="Only Cloud Data if you did not, when Registering!", font=('Gautami', 15),fg="white", bg='cadet blue')
	notif.pack(side='bottom', pady=3)

	#------------Images--Support Page---------------------------

	Cloud_bg= PhotoImage(file="cloudpage.png")	#---Background

	#__________________Bg_Image #3399FF
	Cl_Bck=Label(Cloud, image=Cloud_bg)
	Cl_Bck.Cloud_bg=Cloud_bg
	Cl_Bck.pack(side='bottom')


	#=================================================================
	#========= REG ENTRY ==============================================
	#FIRSTNAME
	firstname = ttk.Entry(Cloud, background="white", textvariable=Fname, style='info.TEntry', font=('Helvetica', 10, "bold"))
	firstname.place(x=253, y=136, width=230)

	#Validate------
	validate_name = Cloud.register(checkname) #callback
	firstname.config(validate="key", validatecommand=(validate_name, "%P"))
	#------------------------------------------------------------------------------------------

	#MIDDLENAME
	middlename = ttk.Entry(Cloud, background="white", textvariable=Mname, style='info.TEntry', font=('Helvetica', 10, "bold"))
	middlename.place(x=253, y=178, width=230)

	#Validate------
	validate_name = Cloud.register(checkname) #callback
	middlename.config(validate="key", validatecommand=(validate_name, "%P"))
	#------------------------------------------------------------------------------------------

	#LASTNAME
	lastname = ttk.Entry(Cloud, background="white", textvariable=Lname, style='info.TEntry', font=('Helvetica', 10, "bold"))
	lastname.place(x=253, y=220, width=230)

	#Validate------
	validate_name = Cloud.register(checkname) #callback
	lastname.config(validate="key", validatecommand=(validate_name, "%P"))

	#------------------------------------------------------------------------------------------
	#MATRIC NUMBER
	matric_no = ttk.Entry(Cloud, background="white", textvariable=Matno, style='info.TEntry', font=('Helvetica', 10, "bold"))
	matric_no.place(x=253, y=262, width=230)

	#Validate------
	validate_matric_number=Cloud.register(Check_MatricNo) #validation register
	matric_no.config(validate="key", validatecommand=(validate_matric_number,"%P"))

	#------------------------------------------------------------------
	#GENDER
	#gen_var = tkinter.Strinpass_word()
	gender = ttk.OptionMenu(Cloud, Gender, 'Select Gender', *list(['Male','Female']))
	gender.config(width=26)
	gender.place(x=253, y=303)

	#PASSWORD
	passw = ttk.Entry(Cloud, background="white", textvariable=Password, style='success.TEntry', font=('Helvetica', 10, "bold"))
	passw .place(x=253, y=343, width=230)
	#------------------------------------------------------------------
	#DEPARTMENT
	#dept_var = tkinter.Strinpass_word()
	dept = ttk.OptionMenu(Cloud, Depart, 'Select Department', *list(['Accountancy','Agricultural Tech','Agric & Bio Environ Engr','Architectural Tech','Art/Industrial Design','Banking and Finance','Building Tech','Business Admin','Chemical Engr',
		'Computer Engr','Computer Science','Civil Engr','Elect/Elect Engr','Estate Mgt & Valuation','Fishery Tech','Food Tech','Hospitality Mgt Tech','Insurance','Marketing','Mass communication','Mechanical Engr','Mechatronics Engr',
		'Office Tech & Mgt','Science Lab Tech','Statistics','Urban and Regional planing','Horticultural Tech','Quantity Surveying','Leisure & Tourism Technology','Micro Biology','Telecom Engr']))
	dept.config(width=26)
	dept.place(x=253, y=384)

	#SUBMIT BUTTON
	Cloud_Btn = ttk.Button(Cloud, text="S u b m i t", command=send_data, style='info.Outline.TButton')
	Cloud_Btn.place(x=130, y=450, width=286)
	#binding submit button to enter key
	Cloud.bind('<Return>', lambda event=None: Cloud_Btn.invoke())

	#CLEARBUTTON
	Clear_Btn = ttk.Button(Cloud, text="Clear", command=clear, style='warning.Outline.TButton')
	Clear_Btn.place(x=420, y=450, width=62)

	#LABEL
	time = Label(Cloud, textvariable=DD, font=('Gautami', 15),fg="sky blue", bg='white')
	time.place(x=470, y=17)






#=============== C O M P L A I N T    P A G E ======================
def Complaint_page():
	from ttkbootstrap import Style
	from tkinter import ttk
	#----------------------------------------
	Root = Style(theme='united') 
	Root = Root.master
	Root=tkinter.Toplevel()
	Root.title("Complaint Page")
	Root.config(bg="white")
	#root.iconbitmap(r'laspotech_logo.ico')

	# MAKE WINDOWS APPEAR ON CENTER OF SCREEN

	app_width = 500
	app_height = 500

	screen_width = root.winfo_screenwidth()
	screen_height = root.winfo_screenheight()

	x = (screen_width / 2) - (app_width / 2)
	y = (screen_height / 2) - (app_height / 2)

	Root.geometry(f'{app_width}x{app_height}+{int(x)}+{int(y)}')
	
#----------------------------------------------------------------
	Root.resizable(False,False)
	Root.focus_force()
	Root.grab_set()

	messagebox.showinfo("Connect to a network", "An internet connection is needed for this operation!", parent=Root)

	def send_complaint():
		try:
			username =  'utomydee@gmail.com'
			password = 'Utomy_dee5'
			to = 'utomydee@gmail.com'
			department = Depart.get()
			email_address = email.get()
			subject = temp_subject.get()
			body = "COMPLAINT" + "\n\n" +  "Department : " + Depart.get() + "\n"  + "Matric Number : " + temp_subject.get() + "\n"  + "Email Address : " + email.get() + "\n\n" + "Message / Complaint :  " + txtRpt.get("1.0", END)
			if subject=="" or department=="Select Department" or len (txtRpt.get("1.0", END))==1: 
				notif.config(text="All fields are required", fg="red")
				return

			else:
				#MESSAGE
				finalMessage = 'Subject: {}\n\n{}'.format(subject, body)
				sever = smtplib.SMTP('smtp.gmail.com', 587)
				sever.starttls()
				sever.login(username, password)
				sever.sendmail(username, to, finalMessage)
				notif.config(text="Request Has been sent successfully!", fg="green")
		except:
				notif.config(text="Error sending request!\nPoor internet connection!", fg='red')


		#Storage
	#temp_receiver = StringVar()
	temp_subject = StringVar()
	email = StringVar()
	complaint_msg = StringVar()

	#RESPONSE------------------------------------------
	notif = Label(Root, text="", font=('Calibri bold', 15), bg='white')
	notif.pack(side='bottom', pady=10)

	#-----------------------------------------------------------------
	frame = Frame (Root, bg='#6699ff')
	frame.place(x=30, y=58, height=1, width=440)

	Label(Root, text = 'Complaint', font=('Century Gothic bold', 24),
		bg ='white', fg='red').place(x=30, y=10)

	Label(Root, text = 'Enter Matric Number', font=('calibri', 15),
		bg ='white', fg='black').place(x=27, y=120)

	Label(Root, text = 'Enter Email Address', font=('calibri', 15),
		bg ='white', fg='black').place(x=297, y=120)

	Label(Root, text = 'Message', font=('calibri', 15),
		bg ='white', fg='black').place(x=27, y=200)



	#------------------------------------------------------------------
	#DEPARTMENT
	Depart = StringVar()
	dept = ttk.OptionMenu(Root, Depart, 'Select Department', *list(['Accountancy','Agricultural Tech','Agric & Bio Environ Engr','Architectural Tech','Art/Industrial Design','Banking and Finance','Building Tech','Business Admin','Chemical Engr',
		'Computer Engr','Computer Science','Civil Engr','Elect/Elect Engr','Estate Mgt & Valuation','Fishery Tech','Food Tech','Hospitality Mgt Tech','Insurance','Marketing','Mass communication','Mechanical Engr','Mechatronics Engr',
		'Office Tech & Mgt','Science Lab Tech','Statistics','Urban and Regional planing','Horticultural Tech','Quantity Surveying','Leisure & Tourism Technology','Micro Biology','Telecom Engr']))
	dept.config(width=56)
	dept.place(x=30, y=70, height=33)

	#---------------------------------------------------------------command=send,

	Matric_No = ttk.Entry(Root, background="white", textvariable=temp_subject,  style='info.TEntry', font=('calibri bold', 13),width=20)
	Matric_No.place(x=30, y=155, height=33)

	Email_Address = ttk.Entry(Root, background="white", textvariable=email, foreground='green', style='info.TEntry', font=('calibri bold', 13),width=24)
	Email_Address.place(x=237, y=155, height=33)

	#Report Message______________
	txtRpt = Text(Root, bg="white", bd=0, selectbackground="blue",  fg="#201E1E", spacing3=2, spacing2=5,  wrap=WORD, undo=True, height=10, font=('Arial', 12))
	txtRpt.place(x=30, y=236, width=420, height=130)

	#ScroolBarFrame
	Scrollframe = Frame (Root, bg='white')
	Scrollframe.place(x=450, y=235, height=132, width=16)

	#ScroolBar-------
	scroll_y = Scrollbar(Scrollframe, orient="vertical", command=txtRpt.yview)
	scroll_y.pack(side=RIGHT, fill='y')
	txtRpt.configure(yscrollcommand=scroll_y.set, height=10)


	#BUTTON_________________________________

	Send_Btn = Button(Root, text='   S e n d   ', bd=0, command=send_complaint, activebackground='green', cursor="hand2", activeforeground='white', font=('calibri', 13),
		fg='white', relief=FLAT, bg='#FF3300')
		#command = lambda : send_mail(Matric_No.get(), Email_Address.get())
	Send_Btn.place(x=30, y=390, width=436)
	#binding login button to enter key
	Root.bind('<Return>', lambda event=None: Send_Btn.invoke())
	#---------------------------------------------


#===================================================================
#======= F O R G E T   P A S S W O R D    P A G E ==================
def Forget_Passw_page():
	from ttkbootstrap import Style
	from tkinter import ttk
	#----------------------------------------
	root3 = Style(theme='yeti') 
	root3 = root3.master
	root3=tkinter.Toplevel()
	root3.title("Password Recovery Page")
	root3.config(bg="white")
	#root.iconbitmap(r'laspotech_logo.ico')

	# MAKE WINDOWS APPEAR ON CENTER OF SCREEN

	app_width = 500
	app_height = 500

	screen_width = root.winfo_screenwidth()
	screen_height = root.winfo_screenheight()

	x = (screen_width / 2) - (app_width / 2)
	y = (screen_height / 2) - (app_height / 2)

	root3.geometry(f'{app_width}x{app_height}+{int(x)}+{int(y)}')
	
#----------------------------------------------------------------
	root3.resizable(False,False)
	root3.focus_force()
	root3.grab_set()

	messagebox.showinfo("Connect to a network", "An internet connection is needed for this operation!", parent=root3)

	def send():
		try:
			username =  'utomydee@gmail.com'
			password = 'Utomy_dee5'
			to = 'utomydee@gmail.com'
			department = Depart.get()
			email = temp_body.get()
			subject = temp_subject.get()
			body = "FORGOT PASSWORD" + "\n\n" + "Email Address : " + temp_body.get() + "\n" + "Department : " + Depart.get()
			if subject=="" or email =="" or department=="Select Department": 
				notif.config(text="All fields are required", fg="red")
				return

			else:
				finalMessage = 'Subject: {}\n\n{}'.format(subject, body)
				sever = smtplib.SMTP('smtp.gmail.com', 587)
				sever.starttls()
				sever.login(username, password)
				sever.sendmail(username, to, finalMessage)
				notif.config(text="Request Has been sent successfully!", fg="green")
		except:
			notif.config(text="Error sending request!\nPoor internet connection!", fg='red')

	#----------------------------------------------

	#Storage
	#temp_receiver = StringVar()
	temp_subject = StringVar()
	temp_body = StringVar()


	#RESPONSE------------------------------------------
	notif = Label(root3, text="", font=('Calibri bold', 15), bg='white')
	notif.pack(side='bottom', pady=10)

	#-----------------------------------------------------------------
	frame = Frame (root3, bg='#6699ff')
	frame.place(x=30, y=68, height=1, width=440)

	Label(root3, text = 'Password Recovery', font=('Century Gothic bold', 24),
		bg ='white', fg='#6699ff').place(x=30, y=18)

	Label(root3, text = 'Enter Matric Number', font=('calibri', 16),
		bg ='white', fg='#6699ff').place(x=30, y=140)

	Label(root3, text = 'Enter Email Address', font=('calibri', 16),
		bg ='white', fg='#6699ff').place(x=30, y=230)



	#------------------------------------------------------------------
	#DEPARTMENT
	Depart = StringVar()
	dept = ttk.OptionMenu(root3, Depart, 'Select Department', *list(['Accountancy','Agricultural Tech','Agric & Bio Environ Engr','Architectural Tech','Art/Industrial Design','Banking and Finance','Building Tech','Business Admin','Chemical Engr',
		'Computer Engr','Computer Science','Civil Engr','Elect/Elect Engr','Estate Mgt & Valuation','Fishery Tech','Food Tech','Hospitality Mgt Tech','Insurance','Marketing','Mass communication','Mechanical Engr','Mechatronics Engr',
		'Office Tech & Mgt','Science Lab Tech','Statistics','Urban and Regional planing','Horticultural Tech','Quantity Surveying','Leisure & Tourism Technology','Micro Biology','Telecom Engr']))
	dept.config(width=56)
	dept.place(x=30, y=88, height=33)
	#dept.place(x=30, y=88, height=33)

	#---------------------------------------------------------------

	Matric_No = ttk.Entry(root3, background="white", textvariable=temp_subject,  style='info.TEntry', font=('calibri bold', 13),width=47)
	Matric_No.place(x=30, y=178, height=33)

	Email_Address = ttk.Entry(root3, background="white", textvariable=temp_body, foreground='green', style='info.TEntry', font=('calibri bold', 13),width=47)
	Email_Address.place(x=30, y=270, height=33)



	Send_Btn = Button(root3, text='   S e n d   ', command=send, bd=0, activebackground='green', cursor="hand2", activeforeground='white', font=('calibri', 13),
		fg='black', relief=FLAT, bg='#6699ff')
		#command = lambda : send_mail(Matric_No.get(), Email_Address.get())
	Send_Btn.place(x=30, y=336, width=436)
	#binding login button to enter key
	root3.bind('<Return>', lambda event=None: Send_Btn.invoke())
	#---------------------------------------------



# SUPPORT PAGE G U I -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# SUPPORT PAGE G U I -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
def support_page():
	root2=tkinter.Toplevel()
	root2.title("Support Page")
	#root.iconbitmap(r'laspotech_logo.ico')
	root2.geometry("1150x620+50+50")


	# MAKE WINDOWS APPEAR ON CENTER OF SCREEN

	"""app_width = 1150
	app_height = 620

	screen_width = root.winfo_screenwidth()
	screen_height = root.winfo_screenheight()

	x = (screen_width / 2) - (app_width / 2)
	y = (screen_height / 2) - (app_height / 2)

	root.geometry(f'{app_width}x{app_height}+{int(x)}+{int(y)}') """
	
#----------------------------------------------------------------
	root2.resizable(False,False)
	root2.focus_force()
	root2.grab_set()

#------------Images--Support Page---------------------------

	Support_bg= PhotoImage(file="supportpage.png")	#---Background
	Forgot_Psw_button= PhotoImage(file="ForgotPswBtn.png")
	Complaints_btn= PhotoImage(file="Complaint_Btn.png")
	Others_btn= PhotoImage(file="Others_Btn.png")


#__________________Bg_Image #3399FF
	Sp_Bck=Label(root2, image=Support_bg)
	Sp_Bck.Support_bg=Support_bg
	Sp_Bck.pack()

#---Support Frame Line--------------------------
	Support_Frame = Frame(root2, bg='white', width=400)
	Support_Frame.place(x=100, y=200)

	Support_Frame = Frame(root2, bg='white', width=400)
	Support_Frame.place(x=100, y=356)



#---Buttons------------------------
	def Forget_hover(self):
		Forget_hover_image= PhotoImage (file="ForgotPswBtn_Hover.png")
		Forget_Psw_Btn.config(image=Forget_hover_image)
		Forget_Psw_Btn.image = Forget_hover_image

	def Forget_changeback(self):
		Forget_hover_image=PhotoImage(file="ForgotPswBtn.png")
		Forget_Psw_Btn.config(image=Forget_hover_image)
		Forget_Psw_Btn.image=Forget_hover_image


	#--FORGET PASSWORD BUTTON----------------------------------------
	Forget_Psw_Btn=Button(root2, command=Forget_Passw_page, image=Forgot_Psw_button, bd=0, bg="#3399FF", cursor="hand2", activebackground="#3399FF", activeforeground="#3399FF")
	Forget_Psw_Btn.Forgot_Psw_button = Forgot_Psw_button
	Forget_Psw_Btn.place(x=685, y=260)#------------------------------
	#-------------binding
	Forget_Psw_Btn.bind("<Enter>", Forget_hover)
	Forget_Psw_Btn.bind("<Leave>", Forget_changeback)



	#--COMPLAINT BUTTON----------------------------------------------
	def Complaint_hover(self):
		Complaint_hover_image= PhotoImage (file="Complaint_Btn_Hover.png")
		Complaint.config(image=Complaint_hover_image)
		Complaint.image = Complaint_hover_image

	def Complaint_changeback(self):
		Complaint_hover_image=PhotoImage(file="Complaint_Btn.png")
		Complaint.config(image=Complaint_hover_image)
		Complaint.image=Complaint_hover_image


	Complaint=Button(root2, image=Complaints_btn, command=Complaint_page, bd=0, bg="#3399FF", cursor="hand2", activebackground="#3399FF", activeforeground="#3399FF")
	Complaint.Complaints_btn = Complaints_btn
	Complaint.place(x=685, y=300)
	#-------------binding
	Complaint.bind("<Enter>", Complaint_hover)
	Complaint.bind("<Leave>", Complaint_changeback)




	#--OTHERS BUTTON-------------------------------------------------
	def Others_Button_hover(self):
		Others_Button_hover_image= PhotoImage (file="Others_Btn_Hover.png")
		Others_Button.config(image=Others_Button_hover_image)
		Others_Button.image = Others_Button_hover_image

	def Others_Button_changeback(self):
		Others_Button_hover_image=PhotoImage(file="Others_Btn.png")
		Others_Button.config(image=Others_Button_hover_image)
		Others_Button.image=Others_Button_hover_image


	Others_Button=Button(root2, image=Others_btn, command=Cloud_page, bd=0, bg="#3399FF", cursor="hand2", activebackground="#3399FF", activeforeground="#3399FF")
	Others_Button.Others_btn = Others_btn
	Others_Button.place(x=685, y=340)
	#-------------binding
	Others_Button.bind("<Enter>", Others_Button_hover)
	Others_Button.bind("<Leave>", Others_Button_changeback)




#==================================================================
#------------------------------------------------------------------








#============== CONNECT LOGIN TO DATABASE ==========================
#============== CONNECT LOGIN TO DATABASE ==========================

def Login_database():

	un = UserName.get()
	print(un)
	ps = Passwords.get()
	print(ps)


	#CONNECTION WITH DATABASE

	conn = sqlite3.connect('LoginDetails.db')
	with conn:
		cursor = conn.cursor()
		cursor.execute("SELECT * from Login where MatricNo=='"+un+"'and Password=='"+ps+"'")
		result = cursor.fetchone()

	if txt_user.get()=="" or txt_pass.get()=="":
				messagebox.showerror("Error","All fields are required!")

	elif result==None:
		messagebox.showwarning("invalid", "You are not a valid user")


	else:
		messagebox.showinfo("Welcome", "User_Name: \n" + UserName.get() + "\n\nPassword: \n" + Passwords.get())





#GUI	#==================================================================
#GUI	#======= L O G I N   W I N D O W   S C R E E N ====================
#GUI	#==================================================================

	
root = tkinter.Tk()
root.title ("My Laspotech Login")
#root.state('zoomed')
root.resizable(False, False)
#root.iconbitmap(r'laspotech_logo.ico')
root.geometry("1150x620+50+50")

# MAKE WINDOWS APPEAR ON CENTER OF SCREEN

"""app_width = 1150
app_height = 620

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

x = (screen_width / 2) - (app_width / 2)
y = (screen_height / 2) - (app_height / 2)

root.geometry(f'{app_width}x{app_height}+{int(x)}+{int(y)}') """

#Login Var-----------------------------------------------------------------
#--------------------------------------------------------------------------
UserName = StringVar()
Passwords = StringVar()
#--------------------------------------------------------------------------

#---BG IMAGE
bg=PhotoImage(file="LoginPage_bg.png")
#---LOGIN BUTTON IMAGE
login_btn=PhotoImage(file="login_button.png")
#---PASSWORD VISIBILITY BUTTON IMAGE
Password_visibility_btn=PhotoImage(file="password_visible.png")
#---REDIRECT BUTTON IMAGE
Redirect_btn=PhotoImage(file="redirect_button.png")
#---REGISTER BUTTON IMAGE
Register_btn=PhotoImage(file="Newuser.png")
#---SUPPORT BUTTON IMAGE
Support_btn=PhotoImage(file="Support_button.png")
#---HELP BUTTON IMAGE
Help_btn=PhotoImage(file="help_button.png")
#---PASSWORD VISIBILITY BUTTON IMAGE
Pass_Vis=PhotoImage(file="password_visible.png")
#---SEPERATOR IMAGE
Seperator=PhotoImage(file="seperator.png")
#---SEPERATOR IMAGE
see_password=PhotoImage(file="see.png")


#------packing Bg Image to screen-------
bg_image=Label(root, image=bg)
bg_image.pack()


#==================================================================
#====================== F U N C T I O N S =========================

def register():
	messagebox.showinfo("Connect to a network", "It Adviced to have an internet connection for this operation so\nas to save and secure data and have easy access to contact\nour support team.", parent=root)
	root.destroy()
	os.system("Registratuion_page.py")

def Password_Not_Visible():
	txt_pass2.destroy()
	Pass_Visibility2.destroy()	#forget_pack()

def Password_Visible():
	global txt_pass2 #make the function global so all fuctions can access it
	global Pass_Visibility2

	txt_pass2=Entry(root, bg="white", textvariable=Passwords, bd=0, font=("calibri",13))
	txt_pass2.place(x=813, y=326, width=212, height=23)

	Pass_Visibility2=Button(root, image=see_password, command=Password_Not_Visible, bd=0, bg="white", cursor="hand2", activebackground="white", activeforeground="white")
	Pass_Visibility2.place(x=1026, y=330)


#==================================================================
#================== B U T T O N   H O V E R S =====================
#==========
# LOGIN HOVER_EFFECT
def login_button_change(event):
	login_button_image= PhotoImage (file="login_button_hover.png")
	login_button.config(image=login_button_image)
	login_button.image = login_button_image
# LOGIN HOVER_EFFECT
def login_button_changeback(event):
	login_button_image=PhotoImage(file="login_button.png")
	login_button.config(image=login_button_image)
	login_button.image=login_button_image

#-----------------------------------------------------------------

# RESGISTER HOVER_EFFECT
def reg_button_change(event):
	reg_button_image= PhotoImage (file="Newuser_hover.png")
	reg_button.config(image=reg_button_image)
	reg_button.image = reg_button_image
# REGISTER HOVER_EFFECT
def reg_button_changeback(event):
	reg_button_image=PhotoImage(file="Newuser.png")
	reg_button.config(image=reg_button_image)
	reg_button.image=reg_button_image

#-----------------------------------------------------------------

# PORTAL LOGIN HOVER_EFFECT
def portal_button_change(event):
	portal_button_image= PhotoImage (file="redirect_button_hover.png")
	portal_button.config(image=portal_button_image)
	portal_button.image = portal_button_image
# PORTAL LOGIN HOVER_EFFECT
def portal_button_changeback(event):
	portal_button_image=PhotoImage(file="redirect_button.png")
	portal_button.config(image=portal_button_image)
	portal_button.image=portal_button_image


#-----------------------------------------------------------------

# SUPPORT HOVER_EFFECT
def support_button_change(event):
	support_button_image= PhotoImage (file="Support_button_hover.png")
	support_button.config(image=support_button_image)
	support_button.image = support_button_image
# SUPPORT HOVER_EFFECT
def support_button_changeback(event):
	support_button_image=PhotoImage(file="Support_button.png")
	support_button.config(image=support_button_image)
	support_button.image=support_button_image

#-----------------------------------------------------------------

# FAQ HOVER_EFFECT
def faq_button_change(event):
	faq_button_image= PhotoImage (file="help_button_hover.png")
	faq_button.config(image=faq_button_image)
	faq_button.image = faq_button_image
# FAQ HOVER_EFFECT
def faq_button_changeback(event):
	faq_button_image=PhotoImage(file="help_button.png")
	faq_button.config(image=faq_button_image)
	faq_button.image=faq_button_image

#-----------------------------------------------------------------

# FAQ HOVER_EFFECT
def Pass_Visibility_change(event):
	Pass_Visibility_image= PhotoImage (file="password_visible_hover.png")
	Pass_Visibility.config(image=Pass_Visibility_image)
	Pass_Visibility.image = Pass_Visibility_image
# FAQ HOVER_EFFECT
def Pass_Visibility_changeback(event):
	Pass_Visibility_image=PhotoImage(file="password_visible.png")
	Pass_Visibility.config(image=Pass_Visibility_image)
	Pass_Visibility.image=Pass_Visibility_image



#==================================================================
#==================================================================

#=========LOGIN ENTRY==============================================

#---U S E R N A M E      E N T R Y -------------------------------
txt_user=Entry(root, bg="white", textvariable=UserName, disabledbackground='white', bd=0, font=("calibri",13))
txt_user.place(x=813, y=242, width=233, height=23) #--------------

#-------------P L A C E  H O L D E R    for username
def Username_onclick(b):
	txt_user.configure(state=NORMAL, font=("calibri",13))
	txt_user.delete(0, END)
	txt_user.unbind('<Button-1>', on_click_id)

#binding
txt_user.insert(0,  ' Enter Matric Number ')
txt_user.configure(state=DISABLED, font=("calibri italic",12))
on_click_id = txt_user.bind('<Button-1>', Username_onclick)



#---P A S S W O R D   E N T R Y
txt_pass=Entry(root, bg="white", textvariable=Passwords, bd=0, show="*", disabledbackground='white', font=("calibri",13))
txt_pass.place(x=813, y=326, width=212, height=23)

#-------------P L A C E  H O L D E R    for password
def Password_onclick(b):
	txt_pass.configure(state=NORMAL, font=("calibri",13), show="*")
	txt_pass.delete(0, END)
	txt_pass.unbind('<Button-1>', on_click_id2)

#binding
txt_pass.insert(0,  ' Enter Password ')
txt_pass.configure(state=DISABLED, font=("calibri italic",12), show="")
on_click_id2 = txt_pass.bind('<Button-1>', Password_onclick)



#================PASSWORD VISIBILITY BUTTON=======================
#=================================================================
Pass_Visibility=Button(root, image=Pass_Vis, command=Password_Visible, bd=0, bg="white", cursor="hand2", activebackground="white", activeforeground="white")
Pass_Visibility.place(x=1026, y=330)
#--------------------
#-------------binding
Pass_Visibility.bind("<Enter>", Pass_Visibility_change)
Pass_Visibility.bind("<Leave>", Pass_Visibility_changeback)

#=================================================================
#=================================================================

#===================LOGIN BUTTON FRAME============================
#=================================================================


#---BUTTON FRAME
btn_frame=Frame(root, bg="white")
btn_frame.place(x=830, y=400, height=50, width=200)

#--LOGIN BUTTON
login_button=Button(btn_frame, image=login_btn, command=Login_database, bd=0, bg="white", cursor="hand2", activebackground="white", activeforeground="white")
login_button.pack()
#binding login button to enter key
root.bind('<Return>', lambda event=None: login_button.invoke())
#--------------------
#-------------binding
login_button.bind("<Enter>", login_button_change)
login_button.bind("<Leave>", login_button_changeback)


#===================REGISTER BUTTON FRAME========================
#================================================================

#---BUTTON FRAME
reg_frame=Frame(root, bg="white")
reg_frame.place(x=956, y=365, height=20, width=80)

#--REG BUTTON
reg_button=Button(reg_frame, command=register, image=Register_btn, bd=0, bg="white", cursor="hand2", activebackground="white", activeforeground="white")
reg_button.pack()
#--------------------
#-------------binding
reg_button.bind("<Enter>", reg_button_change)
reg_button.bind("<Leave>", reg_button_changeback)

#===================PORTAL BUTTON FRAME==========================
#================================================================

#---BUTTON FRAME
portal_frame=Frame(root, bg="white")
portal_frame.place(x=895, y=460, height=20, width=140)

#--PORTAL BUTTON
def Open_Portal ():
	webbrowser.open("https://me.mylaspotech.edu.ng")

portal_button=Button(portal_frame, command=Open_Portal, image=Redirect_btn, bd=0, bg="white", cursor="hand2", activebackground="white", activeforeground="white")
portal_button.pack()
#--------------------
#-------------binding
portal_button.bind("<Enter>", portal_button_change)
portal_button.bind("<Leave>", portal_button_changeback)


#====================SUPPORT / FAQ BUTTON FRAME==================
#================================================================

#---BUTTON FRAME
support_frame=Frame(root, bg="#00AEEF")#00AEEF
support_frame.place(x=970, y=0, height=40, width=180)		#place(x=670, y=0, height=40, width=160)#0098DA

#----------------
#---label
label=Label(support_frame, image=Seperator, bg="#00AEEF")
label.place(x=100, y=8)

#--------------------------------------------------------
#--SUPPORT BUTTON
support_button=Button(support_frame, image=Support_btn, command=support_page, bd=0, bg="#00AEEF", cursor="hand2", activebackground="#00AEEF", activeforeground="#00AEEF")
support_button.place(x=12, y=12)#------------------------
#--------------------
#-------------binding
support_button.bind("<Enter>", support_button_change)
support_button.bind("<Leave>", support_button_changeback)

#--FAQ BUTTON
faq_button=Button(support_frame, image=Help_btn, bd=0, bg="#00AEEF", cursor="hand2", activebackground="#00AEEF", activeforeground="#00AEEF")
faq_button.place(x=133, y=12)
#--------------------
#-------------binding
faq_button.bind("<Enter>", faq_button_change)
faq_button.bind("<Leave>", faq_button_changeback)









root.mainloop()