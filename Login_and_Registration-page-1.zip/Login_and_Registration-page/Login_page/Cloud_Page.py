from tkinter import*
import tkinter
import os
import smtplib
from ttkbootstrap import Style
from tkinter import ttk
from tkinter import messagebox
import time;
import datetime



def send_data():
	try:
		username =  'utomydee@gmail.com'
		password = 'Utomy_dee5'
		Firstname_ =Fname.get()
		MiddleName_ = Mname.get()
		LastName_ = Lname.get() 
		MatricNumber_ =  Matno.get()
		Gender_  = Gender.get() 
		Password_ = Password.get()
		Department_ = Depart.get()
		subject = Matno.get()
		body = "NEW USER (Cloud Data)" + "\n\n" + "Firstname : " + Fname.get() + "\n" + "Middle Name : " + Mname.get() + "\n" + "Last Name : " + Lname.get() + "\n" + "Matric Number : " +  Matno.get() + "\n" + "Gender : " + Gender.get() + "\n" + "Password : " + Password.get()+ "\n" + "Department : " + Depart.get()
		if subject=="" or Firstname_=="" or MiddleName_=="" or LastName_=="" or MatricNumber_=="" or Gender_=="Select Gender"  or Password_==""  or Department_=="Select Department": 
			messagebox.showwarning("Invalid", "All fields are required!\nNo field should be left empty!")
			#notif.config(text=" All fiels are required! No field should be left empty! ", fg="#FFFF00")
			return

		elif len(Password.get())<=6:
			messagebox.showinfo("Invalid", "Password Incorrect\n\nPassword should be at least 7 characters")
			return
		elif len(Matno.get())!=10:
			messagebox.showinfo("Invalid Matric Number", "Enter a valid Matric Number")
			return

		else:
			finalMessage = 'Subject: {}\n\n{}'.format(subject, body)
			sever = smtplib.SMTP('smtp.gmail.com', 587)
			sever.starttls()
			sever.login(username, password)
			sever.sendmail(username, to, finalMessage)
			notif.config(text="Request Has been sent successfully!", fg="#CCCC33")
	except:
		notif.config(text="Error sending request! Poor internet connection!", fg='#FFFF00')



#COMMANDS AND FUNCTIONS
def clear(): 	#clear entries
	firstname.delete(0,END)
	middlename.delete(0,END)
	lastname.delete(0,END)
	matric_no .delete(0,END)
	Gender.set('Select Gender')
	passw.delete(0,END)
	Depart.set('Select Department')
	notif.config(text="Only Cloud Data if you did not, when Registering!", fg='white')


#CALLBACK FUNCTION --------NAME
def checkname(name):
	if name.isalpha():
		return True

	if name=="":
		return True

	else:
		messagebox.showwarning("Invalid","Not allowed "+name[-1])
		return False

#CHECK MATRIC NO REQUIREMENT
def Check_MatricNo(mat):
	if mat.isdigit():
		return True
	if len(str(mat))==0:
		return True
	else:
		messagebox.showwarning("Invalid","Invalid Entry")
		return False

#CHECK PASSWORD REQUIREMENT
"""def checkpassword():
	if len(Password.get())<=6:
		messagebox.showwarning("Invalid", "Password length is too short\n\nPassword should be at least 7 characters")
	else:
		return True
"""
#----------------------------------------------

Cloud = Style(theme='lumen') 
Cloud = Cloud.master
Cloud.config(bg="cadet blue")
# MAKE WINDOWS APPEAR ON CENTER OF SCREEN

app_width = 616
app_height = 640

screen_width = Cloud.winfo_screenwidth()
screen_height = Cloud.winfo_screenheight()

x = (screen_width / 2) - (app_width / 2)
y = (screen_height / 2) - (app_height / 2)

Cloud.geometry(f'{app_width}x{app_height}+{int(x)}+{int(y)}') 
#Root.eval(f'tk::PlaceWindow . center')


#==================================================================
#CREATING DATA SELECTION VARIABLE ON GUI
Fname = StringVar()
Mname = StringVar()
Lname = StringVar()
Matno = StringVar()
Gender = StringVar()
Password = StringVar()
Depart = StringVar()

DD=StringVar() # Date
DD.set(time.strftime("%d-%m-%Y"))

#RESPONSE------------------------------------------
notif = Label(Cloud, text="Only Cloud Data if you did not, when Registering!", font=('Gautami', 15),fg="white", bg='cadet blue')
notif.pack(side='bottom', pady=3)

#------------Images--Support Page---------------------------

Cloud_bg= PhotoImage(file="cloudpage.png")	#---Background

#__________________Bg_Image #3399FF
Cl_Bck=Label(Cloud, image=Cloud_bg)
Cl_Bck.Cloud_bg=Cloud_bg
Cl_Bck.pack(side='bottom')


#=================================================================
#========= REG ENTRY ==============================================
#FIRSTNAME
firstname = ttk.Entry(Cloud, background="white", textvariable=Fname, style='info.TEntry', font=('Helvetica', 10, "bold"))
firstname.place(x=253, y=136, width=230)

#Validate------
validate_name = Cloud.register(checkname) #callback
firstname.config(validate="key", validatecommand=(validate_name, "%P"))
#------------------------------------------------------------------------------------------

#MIDDLENAME
middlename = ttk.Entry(Cloud, background="white", textvariable=Mname, style='info.TEntry', font=('Helvetica', 10, "bold"))
middlename.place(x=253, y=178, width=230)

#Validate------
validate_name = Cloud.register(checkname) #callback
middlename.config(validate="key", validatecommand=(validate_name, "%P"))
#------------------------------------------------------------------------------------------

#LASTNAME
lastname = ttk.Entry(Cloud, background="white", textvariable=Lname, style='info.TEntry', font=('Helvetica', 10, "bold"))
lastname.place(x=253, y=220, width=230)

#Validate------
validate_name = Cloud.register(checkname) #callback
lastname.config(validate="key", validatecommand=(validate_name, "%P"))

#------------------------------------------------------------------------------------------
#MATRIC NUMBER
matric_no = ttk.Entry(Cloud, background="white", textvariable=Matno, style='info.TEntry', font=('Helvetica', 10, "bold"))
matric_no.place(x=253, y=262, width=230)

#Validate------
validate_matric_number=Cloud.register(Check_MatricNo) #validation register
matric_no.config(validate="key", validatecommand=(validate_matric_number,"%P"))

#------------------------------------------------------------------
#GENDER
#gen_var = tkinter.Strinpass_word()
gender = ttk.OptionMenu(Cloud, Gender, 'Select Gender', *list(['Male','Female']))
gender.config(width=26)
gender.place(x=253, y=303)

#PASSWORD
passw = ttk.Entry(Cloud, background="white", textvariable=Password, style='success.TEntry', font=('Helvetica', 10, "bold"))
passw .place(x=253, y=343, width=230)
#------------------------------------------------------------------
#DEPARTMENT
#dept_var = tkinter.Strinpass_word()
dept = ttk.OptionMenu(Cloud, Depart, 'Select Department', *list(['Accountancy','Agricultural Tech','Agric & Bio Environ Engr','Architectural Tech','Art/Industrial Design','Banking and Finance','Building Tech','Business Admin','Chemical Engr',
	'Computer Engr','Computer Science','Civil Engr','Elect/Elect Engr','Estate Mgt & Valuation','Fishery Tech','Food Tech','Hospitality Mgt Tech','Insurance','Marketing','Mass communication','Mechanical Engr','Mechatronics Engr',
	'Office Tech & Mgt','Science Lab Tech','Statistics','Urban and Regional planing','Horticultural Tech','Quantity Surveying','Leisure & Tourism Technology','Micro Biology','Telecom Engr']))
dept.config(width=26)
dept.place(x=253, y=384)

#SUBMIT BUTTON
Cloud_Btn = ttk.Button(Cloud, text="S u b m i t", command=send_data, style='info.Outline.TButton')
Cloud_Btn.place(x=130, y=450, width=286)

#CLEARBUTTON
Clear_Btn = ttk.Button(Cloud, text="Clear", command=clear, style='warning.Outline.TButton')
Clear_Btn.place(x=420, y=450, width=62)

#LABEL
time = Label(Cloud, textvariable=DD, font=('Gautami', 15),fg="sky blue", bg='white')
time.place(x=470, y=17)







Cloud.mainloop()