from ttkbootstrap import Style
from tkinter import*
import tkinter
from tkinter import messagebox 
import os
from tkinter import ttk
from PIL import ImageGrab
import sqlite3
import smtplib






#==================================================================
#===============REGISTRATION WINDOW SCREEN ========================
#==================================================================

root = Style(theme='yeti') 
root = root.master
root.title ("My Laspotech Registration page")
#self.root.state('zoomed')
root.resizable(False, False)
#self.root.iconbitmap(r'laspotech_logo.ico')
root.geometry("1150x620+50+50")


# MAKE WINDOWS APPEAR ON CENTER OF SCREEN

"""app_width = 1150
app_height = 620

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

x = (screen_width / 2) - (app_width / 2)
y = (screen_height / 2) - (app_height / 2)

root.geometry(f'{app_width}x{app_height}+{int(x)}+{int(y)}') """
#----------------------------------------------------------------

#---BG IMAGE
bg=PhotoImage(file="Registration_page.png")
#---REGISTRATION BUTTON IMAGE
Reg_btn=PhotoImage(file="Reg_Button.png")
#---CLEAR BUTTON IMAGE
clear_btn=PhotoImage(file="clear_button.png")
#---REGISTRATION DONE PAGE
Reg_Done_Page=PhotoImage(file="Done_Register_page.png")
#---BACK TO LOGIN
Login_Page=PhotoImage(file="Back_Login.png")
#---CLOUD
cloud_btn=PhotoImage(file="complete_reg_btn.png")



#------packing Bg Image to screen-------
bg_image=Label(root, image=bg)
bg_image.pack()



#==================================================================
#====================== F U N C T I O N S =========================
def send_to_cloud():
	try:
		username =  'utomydee@gmail.com'
		password = 'Utomy_dee5'
		to = 'utomydee@gmail.com'
		Firstname_ =Fname.get()
		MiddleName_ = Mname.get()
		LastName_ = Lname.get() 
		MatricNumber_ =  Matno.get()
		PhoneNumber_ = Mobile.get() 
		Gender_  = Gender.get() 
		Password_ = Password.get()
		Department_ = Depart.get()
		subject = Matno.get()
		body = "NEW USER" + "\n\n" + "Firstname : " + Fname.get() + "\n" + "Middle Name : " + Mname.get() + "\n" + "Last Name : " + Lname.get() + "\n" + "Matric Number : " +  Matno.get() + "\n" + "Phone Number : " + Mobile.get() + "\n" + "Gender : " + Gender.get() + "\n" + "Password : " + Password.get()+ "\n" + "Department : " + Depart.get()
		if subject=="" or Firstname_=="" or MiddleName_=="" or LastName_=="" or MatricNumber_=="" or PhoneNumber_=="" or Gender_=="Select Gender"  or Password_==""  or Department_=="Select Department": 
			notif.config(text=" All fields are required! No field should be left empty! ", fg="red")
			return

		else:
			finalMessage = 'Subject: {}\n\n{}'.format(subject, body)
			sever = smtplib.SMTP('smtp.gmail.com', 587)
			sever.starttls()
			sever.login(username, password)
			sever.sendmail(username, to, finalMessage)
			notif.config(text="Data successfully clouded!", fg="green")
	except:
		notif.config(text="Error sending request! Poor internet connection! Visit FAQ page for more info", fg='red')


#COMMANDS AND FUNCTIONS
def clear(): 	#clear entries
	firstname.delete(0,END)
	middlename.delete(0,END)
	lastname.delete(0,END)
	matno.delete(0,END)
	phone.delete(0,END)
	Gender.set('Select Gender')
	passw.delete(0,END)
	Depart.set('Select Department')

#CALLBACK FUNCTION --------NAME
def checkname(name):
	if name.isalpha():
		return True

	if name=="":
		return True

	else:
		messagebox.showwarning("Invalid","Not allowed "+name[-1])
		return False


#CHECK MATRIC NO REQUIREMENT
def Check_MatricNo(mat):
	if mat.isdigit():
		return True
	if len(str(mat))==0:
		return True
	else:
		messagebox.showwarning("Invalid","Invalid Entry")
		return False

#CHECK CONTACT REQUIREMENT
def checkcontact(con):
	if con.isdigit():
		return True
	if len(str(con))==0:
		return True
	else:
		messagebox.showwarning("Invalid","Invalid Entry")
		return False

#===========B U T T O N - H O V E R S=================================== 

#==========# REGISTRATION BUTTON HOVER
#_HOVER_EFFECT
def Reg_button_change(event):
	Reg_button_image= PhotoImage (file="Register_button_hover.png")
	Reg_button.config(image=Reg_button_image)
	Reg_button.image = Reg_button_image
#_HOVER_EFFECT
def Reg_button_changeback(event):
	Reg_button_image=PhotoImage(file="Reg_Button.png")
	Reg_button.config(image=Reg_button_image)
	Reg_button.image=Reg_button_image

#==========# CLOUD BUTTON HOVER
#_HOVER_EFFECT
def Cloud_button_change(event):
	Cloud_button_image= PhotoImage (file="complete_reg_btn_hover.png")
	Cloud_button.config(image=Cloud_button_image)
	Cloud_button.image = Cloud_button_image
#_HOVER_EFFECT
def Cloud_button_changeback(event):
	Cloud_button_image=PhotoImage(file="complete_reg_btn.png")
	Cloud_button.config(image=Cloud_button_image)
	Cloud_button.image=Cloud_button_image

	#==========# CLEAR BUTTON HOVER
#_HOVER_EFFECT
def clear_button_change(event):
	clear_button_image= PhotoImage (file="clear_button_hover.png")
	clear_button.config(image=clear_button_image)
	clear_button.image = clear_button_image
#_HOVER_EFFECT
def clear_button_changeback(event):
	clear_button_image=PhotoImage(file="clear_button.png")
	clear_button.config(image=clear_button_image)
	clear_button.image=clear_button_image

#==========# BACK TO LOGIN BUTTON HOVER
#_HOVER_EFFECT
def Exit_button_change(event):
	Exit_button_image= PhotoImage (file="Back_Login_hover.png")
	Exit_button.config(image=Exit_button_image)
	Exit_button.image = Exit_button_image
#_HOVER_EFFECT
def Exit_button_changeback(event):
	Exit_button_image=PhotoImage(file="Back_Login.png")
	Exit_button.config(image=Exit_button_image)
	Exit_button.image=Exit_button_image

#==================================================================
#==================================================================
#==================== D A T A     B A S E =========================
def Register():
#---FIELD VALIDATIONS----------------------------------------------
	if len(phone.get())!=11:
		messagebox.showinfo("Invalid Contact", "Enter a valid Contact",parent=root)

	elif len(matno.get())!=10:
		messagebox.showinfo("Invalid Matric Number", "Enter a valid Matric Number",parent=root)

	elif firstname.get()=="":
		messagebox.showinfo("Empty field","Enter Firstname!",parent=root)

	elif middlename.get()=="":
		messagebox.showinfo("Empty field","Enter Middlename!",parent=root)

	elif lastname.get()=="":
		messagebox.showinfo("Empty field","Enter Lastname!",parent=root)

	elif matno.get()=="":
		messagebox.showinfo("Empty field","Enter Your Matric Number!",parent=root)

	elif phone.get()=="":
		messagebox.showinfo("Empty field","Enter Phone Number!",parent=root)

	elif passw.get()=="":
		messagebox.showinfo("Empty field","You have not created a password!",parent=root)

	elif len(Password.get())<=6:
		messagebox.showinfo("Invalid", "Password length is too short\n\nPassword should be at least 7 characters", parent=root)

	elif Depart.get()=="Select Department":
		messagebox.showinfo("Empty field","Select Department!", parent=root)

	elif Gender.get()=="Gender":
		messagebox.showinfo("Empty field", "Select Gender", parent=root)
	#elif phone.get()=="" or matno.get()=="" or firstname.get() or middlename.get() or lastname.get() or matno.get() or passw.get():
		#messagebox.showerror("Empty field", "All fields are required")"""
#-------------------------------------------------------------------------		

	else:
	
		FNa=Fname.get()
		Mna=Mname.get()
		Lna=Lname.get()
		MNo = Matno.get()
		MNum = Mobile.get()
		Gend = Gender.get()
		Pass1 = Password.get()
		Deptm = Depart.get()
		
		#----------------------------------------------------------------
		print(FNa, Mna, Lna, MNo, MNum, Gend, Pass1, Deptm, type(FNa), type(Mna),
			type(Lna), type(MNo), type(MNum), type(Gend), type(Deptm))



#=======#Registration Successfull
		Reg_Done_Page=PhotoImage(file="Reg_completed.png")
		Done_btn = PhotoImage(file="Done_Register_buttion.png")


		Reg_frame = Frame(root, bg="white")
		Reg_frame.place(x=410, y=56, width=600, height=506)

		Completed = Label (Reg_frame, image=Reg_Done_Page)
		Completed.Reg_Done_Page=Reg_Done_Page
		Completed.pack()

		#RESPONSE------------------------------------------
		#notif = Label(root, text="", font=('Calibri', 15), bg='white')
		#notif.place(x=165, y=416)
#---------------------------------------------------------------------
		Get_User = Label (Reg_frame, bg="White", fg="green", text="" + Lname.get()+ " " + Fname.get(), font=("calibri",30))
		Get_User.place(x=165, y=40)

#_HOVER_EFFECT
		def Bck_login_Button_change(event):
			Bck_login_Button_image= PhotoImage (file="Done_Reg_buttion_hover.png")
			Bck_login_Button.config(image=Bck_login_Button_image)
			Bck_login_Button.image = Bck_login_Button_image

		def Bck_login_Button_changeback(event):
			Bck_login_Button_image=PhotoImage(file="Done_Register_buttion.png")
			Bck_login_Button.config(image=Bck_login_Button_image)
			Bck_login_Button.image=Bck_login_Button_image

#_ Go back to Login Page
		def Login_():
			root.destroy()
			os.system("LoginPage.py")

		Bck_login_Button = Button (Reg_frame, image=Done_btn, command=Login_, bd=0, bg="white", cursor="hand2", activebackground="white", activeforeground="white")
		Bck_login_Button.Done_btn=Done_btn 
		Bck_login_Button.place(x=165, y=416)

		#Binding hover Back to Login Button-----------
		Bck_login_Button.bind("<Enter>", Bck_login_Button_change)
		Bck_login_Button.bind("<Leave>", Bck_login_Button_changeback)


		
#========D A T A  B A S E ==
#=======#Database Connection
		conn = sqlite3.connect('LoginDetails.db')
		with conn:
			cursor=conn.cursor()
			#Querries
			cursor.execute("CREATE TABLE IF NOT EXISTS Login(Name TEXT, MiddleName TEXT,\
			 LastName Text, MatricNo TEXT, MobileNo TEXT, Gender Text, Password Text, Department Text)")

			cursor.execute("INSERT INTO Login(Name, MiddleName, LastName, MatricNo, MobileNo, Gender, Password, Department) VALUES (?,?,?,?,?,?,?,?)",
				(FNa, Mna, Lna, MNo, MNum, Gend, Pass1, Deptm))
			conn.commit()

def Back_to_login():
	root.destroy()
	os.system("LoginPage.py")

#==================================================================
#CREATING DATA SELECTION VARIABLE ON GUI
Fname = StringVar()
Mname = StringVar()
Lname = StringVar()
Matno = StringVar()
Mobile = StringVar()
Gender = StringVar()
Password = StringVar()
Depart = StringVar()


#==================================================================


#==================================================================
#==================================================================
#==================================================================
#RESPONSE------------------------------------------
notif = Label(root, text="Make sure to Click the Cloud Button before Register! (For easy access to support team)", font=('Calibri italic', 11), bg='white')
notif.place(x=453, y=555)

#==================================================================

#========= REG ENTRY ==============================================
#FIRSTNAME
firstname = ttk.Entry(root, background="white", textvariable=Fname, style='info.TEntry', font=('Helvetica', 10, "bold"))
firstname.place(x=496, y=168, width=150)
#Validate entry
validate_name = root.register(checkname) #callback
firstname.config(validate="key", validatecommand=(validate_name, "%P"))

#------------------------------------------------------------------
#MIDDLE NAME
middlename = ttk.Entry(root, background="white", textvariable=Mname, style='info.TEntry', font=('Helvetica', 10, "bold"))
middlename.place(x=655, y=168, width=150)
#Validate entry
validate_name = root.register(checkname) #callback
middlename.config(validate="key", validatecommand=(validate_name, "%P"))

#------------------------------------------------------------------
#LAST NAME
lastname = ttk.Entry(root, background="white", textvariable=Lname, style='info.TEntry', font=('Helvetica', 10, "bold"))
lastname.place(x=814, y=168, width=150)
#Validate entry
validate_name = root.register(checkname) #callback
lastname.config(validate="key", validatecommand=(validate_name, "%P"))

#------------------------------------------------------------------
#MATRIC NO
matno = ttk.Entry(root, background="white", textvariable=Matno, style='info.TEntry', font=('Helvetica', 10, "bold"))
matno.place(x=496, y=233, width=465) 
#Check if Alphabet is included in contact
validate_matric_number=root.register(Check_MatricNo) #validation register
matno.config(validate="key", validatecommand=(validate_matric_number,"%P"))


#------------------------------------------------------------------
#PHONE NO
phone = ttk.Entry(root, background="white", textvariable=Mobile, style='info.TEntry', font=('Helvetica', 10, "bold"))
phone.place(x=496, y=299, width=465)
#Check if Alphabet is included in contact
validate_contact=root.register(checkcontact) #validation register
phone.config(validate="key", validatecommand=(validate_contact,"%P"))

#------------------------------------------------------------------
#GENDER
#gen_var = tkinter.Strinpass_word()
gender = ttk.OptionMenu(root, Gender, 'Select Gender', *list(['Male','Female']))
gender.config(width=23)
gender.place(x=496, y=363)

#------------------------------------------------------------------
#PASSWORD
passw = ttk.Entry(root, background="white", textvariable=Password, style='success.TEntry', font=('Helvetica', 10, "bold"))
passw.place(x=746, y=363, width=214)

#------------------------------------------------------------------
#DEPARTMENT
#dept_var = tkinter.Strinpass_word()
dept = ttk.OptionMenu(root, Depart, 'Select Department', *list(['Accountancy','Agricultural Tech','Agric & Bio Environ Engr','Architectural Tech','Art/Industrial Design','Banking and Finance','Building Tech','Business Admin','Chemical Engr',
	'Computer Engr','Computer Science','Civil Engr','Elect/Elect Engr','Estate Mgt & Valuation','Fishery Tech','Food Tech','Hospitality Mgt Tech','Insurance','Marketing','Mass communication','Mechanical Engr','Mechatronics Engr',
	'Office Tech & Mgt','Science Lab Tech','Statistics','Urban and Regional planing','Horticultural Tech','Quantity Surveying','Leisure & Tourism Technology','Micro Biology','Telecom Engr']))
dept.config(width=59)
dept.place(x=496, y=465)


#====================== B U T T O N S ============================
#=================================================================
#FRAME
#REG FRAME
Reg = Frame(root, bg="white")
Reg.place(x=460, y=515, width=499, height=35)

#--REGISTRATION BUTTON--------------------------------------------
Reg_button=Button(Reg, image=Reg_btn, command= Register, bd=0, bg="white", cursor="hand2", activebackground="white", activeforeground="white")
Reg_button.place(x=34, y=2) #-------------------------------------

#Binding hover Registration Button-----------
Reg_button.bind("<Enter>", Reg_button_change)
Reg_button.bind("<Leave>", Reg_button_changeback)
#-----------------------------------------------

#--CLOUD BUTTON--------------------------------------------
Cloud_button=Button(Reg, image=cloud_btn, command=send_to_cloud, bd=0, bg="white", cursor="hand2", activebackground="white", activeforeground="white")
Cloud_button.place(x=329, y=2) #-------------------------------------

#Binding hover Registration Button-----------
Cloud_button.bind("<Enter>", Cloud_button_change)
Cloud_button.bind("<Leave>", Cloud_button_changeback)
#-----------------------------------------------

#--CLEAR BUTTON---------------------------------------------------
clear_button=Button(root, image=clear_btn, bd=0, command=clear, bg="white", cursor="hand2", activebackground="white", activeforeground="white")
clear_button.place(x=970, y=130)#---------------------------------
#Binding clear Button-----------
clear_button.bind("<Enter>", clear_button_change)
clear_button.bind("<Leave>", clear_button_changeback)

#--BACK TO LOGIN BUTTON-------------------------------------------
Exit_button=Button(root, image=Login_Page, bd=0, command=Back_to_login, bg="white", cursor="hand2", activebackground="white", activeforeground="white")
Exit_button.place(x=410, y=66)#-----------------------------------
#Binding Exit Button-----------
Exit_button.bind("<Enter>", Exit_button_change)
Exit_button.bind("<Leave>", Exit_button_changeback)

#=================================================================
#=================================================================
#messagebox.showinfo("Connect to a network", "It Adviced to have an internet connection for this operation so\nas to save and secure data and have easy access to contact\nour support team.", parent=root)










root.mainloop()